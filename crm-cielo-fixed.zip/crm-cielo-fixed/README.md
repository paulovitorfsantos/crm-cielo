# CRM Cielo - Gerenciador de Leads

Um CRM moderno e responsivo desenvolvido com React + Vite + Tailwind CSS para gerenciar leads e acompanhar o funil de vendas.

## 🚀 Características

- ✅ Dashboard com gráficos e estatísticas
- ✅ Cadastro e gerenciamento de clientes
- ✅ Filtros avançados de busca
- ✅ Gestão de taxas e concorrentes
- ✅ Classificação de clientes (quente, morno, frio)
- ✅ Exportação de dados em CSV
- ✅ Interface responsiva (mobile, tablet, desktop)
- ✅ Armazenamento local (localStorage)

## 📋 Requisitos

- Node.js 16+ 
- npm ou yarn

## 🛠️ Instalação Local

```bash
# Clonar o repositório
git clone https://github.com/seu-usuario/crm-cielo.git
cd crm-cielo

# Instalar dependências
cd frontend
npm install

# Executar em desenvolvimento
npm run dev

# Build para produção
npm run build

# Preview da build
npm run preview
```

A aplicação estará disponível em `http://localhost:3000`

## 🌐 Deploy no Vercel

### Opção 1: Deploy Automático (Recomendado)

1. Faça push do código para o GitHub
2. Acesse [vercel.com](https://vercel.com)
3. Clique em "New Project"
4. Selecione seu repositório
5. Configure as variáveis de ambiente (se necessário)
6. Clique em "Deploy"

### Opção 2: Deploy Manual via CLI

```bash
# Instalar Vercel CLI
npm install -g vercel

# Fazer deploy
vercel
```

## 📁 Estrutura do Projeto

```
crm-cielo/
├── frontend/
│   ├── src/
│   │   ├── App.jsx          # Componente principal
│   │   ├── main.jsx         # Ponto de entrada
│   │   └── index.css        # Estilos globais
│   ├── index.html           # HTML base
│   ├── package.json         # Dependências
│   ├── vite.config.js       # Configuração Vite
│   ├── vercel.json          # Configuração Vercel
│   └── tailwind.config.js   # Configuração Tailwind
├── vercel.json              # Configuração raiz Vercel
└── README.md                # Este arquivo
```

## 🔧 Configuração

### Variáveis de Ambiente

Se precisar de variáveis de ambiente, crie um arquivo `.env.local`:

```
VITE_API_URL=https://sua-api.com
```

## 📊 Funcionalidades Principais

### Dashboard
- Visualização de estatísticas gerais
- Gráficos de clientes por status
- Análise de taxas

### Clientes
- Adicionar, editar e deletar clientes
- Filtrar por status, classificação e período
- Buscar por documento ou nome
- Visualizar detalhes completos

### Taxas
- Registrar taxas de concorrentes
- Comparar taxas
- Histórico de taxas

### Exportação
- Exportar dados em CSV
- Compatível com Excel e Google Sheets

## 🎨 Personalização

### Cores e Tema

Edite `frontend/tailwind.config.js` para personalizar cores e estilos.

### Concorrentes

Edite a lista de concorrentes em `frontend/src/App.jsx`:

```javascript
const concorrentes = [
  'Stone', 'Rede', 'GetNet', 'PagSeguro', 'Mercado Pago',
  // Adicione mais aqui
];
```

## 💾 Dados

Os dados são armazenados no `localStorage` do navegador. Para sincronizar com um backend:

1. Crie uma API REST
2. Modifique as funções de salvar/carregar em `App.jsx`
3. Substitua `localStorage` por chamadas HTTP

## 🐛 Troubleshooting

### Erro ao fazer build
```bash
# Limpar cache
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Erro ao fazer deploy no Vercel
- Verifique se `vercel.json` está na raiz do projeto
- Confirme que `outputDirectory` aponta para `frontend/dist`
- Verifique os Build Logs no painel do Vercel

### Dados não persistem
- Verifique se localStorage está habilitado no navegador
- Tente limpar cache e cookies
- Use DevTools para inspecionar Application > Local Storage

## 📝 Licença

Este projeto é de código aberto e está disponível sob a licença MIT.

## 👨‍💻 Suporte

Para dúvidas ou problemas, abra uma issue no GitHub ou entre em contato.

---

**Desenvolvido com ❤️ para gerentes de negócios**
