# 🚀 Guia Completo de Deploy no Vercel

Este guia resolve **todos os problemas** que você estava enfrentando e oferece uma solução definitiva.

## ⚠️ O Que Estava Errado

1. **Configuração Vercel incorreta**: O `vercel.json` estava no frontend, não na raiz
2. **Sem rewrite de rotas**: Aplicações React precisam redirecionar todas as rotas para `index.html`
3. **Build command duplicado**: Estava instalando dependências duas vezes
4. **Output directory incorreto**: Não apontava para a pasta correta

## ✅ O Que Foi Corrigido

- ✓ `vercel.json` movido para a raiz do projeto
- ✓ Rewrites configurados para SPA (Single Page Application)
- ✓ Build command otimizado
- ✓ Output directory apontando para `frontend/dist`
- ✓ Configuração Vite otimizada para produção
- ✓ `.vercelignore` criado para ignorar arquivos desnecessários

## 📋 Pré-requisitos

- Conta no [GitHub](https://github.com)
- Conta no [Vercel](https://vercel.com)
- Git instalado localmente

## 🎯 Passo a Passo para Deploy

### 1️⃣ Preparar o Repositório GitHub

```bash
# Navegar até a pasta do projeto
cd crm-cielo-fixed

# Inicializar git (se não estiver inicializado)
git init

# Adicionar todos os arquivos
git add .

# Fazer commit inicial
git commit -m "Corrigido: Deploy no Vercel com configuração correta"

# Adicionar remote (substitua seu-usuario e seu-repo)
git remote add origin https://github.com/seu-usuario/seu-repo.git

# Fazer push para main
git branch -M main
git push -u origin main
```

### 2️⃣ Conectar ao Vercel

**Opção A: Via Dashboard Vercel (Recomendado)**

1. Acesse [vercel.com](https://vercel.com)
2. Clique em "New Project"
3. Clique em "Import Git Repository"
4. Selecione seu repositório do GitHub
5. Vercel detectará automaticamente que é um projeto Vite
6. Clique em "Deploy"

**Opção B: Via Vercel CLI**

```bash
# Instalar Vercel CLI
npm install -g vercel

# Fazer deploy
vercel

# Seguir as instruções interativas
```

### 3️⃣ Configurar Variáveis de Ambiente (se necessário)

Se sua aplicação precisa de variáveis de ambiente:

1. No painel do Vercel, vá para "Settings"
2. Clique em "Environment Variables"
3. Adicione suas variáveis
4. Redeploy o projeto

### 4️⃣ Verificar o Deploy

1. Acesse o link fornecido pelo Vercel
2. Verifique se a aplicação carrega corretamente
3. Teste todas as funcionalidades
4. Verifique o console (F12) para erros

## 🔍 Verificar Logs de Build

Se algo der errado:

1. No painel do Vercel, clique em "Deployments"
2. Selecione o deployment mais recente
3. Clique em "Build Logs"
4. Procure por erros (linhas em vermelho)

## ✨ Arquivos Críticos Explicados

### `vercel.json` (Raiz do Projeto)
```json
{
  "buildCommand": "cd frontend && npm install && npm run build",
  "outputDirectory": "frontend/dist",
  "framework": "vite",
  "rewrites": [
    {
      "source": "/(.*)",
      "destination": "/index.html"
    }
  ]
}
```

**O que faz:**
- `buildCommand`: Navega para frontend, instala dependências e faz build
- `outputDirectory`: Aponta para a pasta de saída do Vite
- `rewrites`: Redireciona todas as rotas para index.html (necessário para React Router)

### `frontend/vite.config.js`
```javascript
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    minify: 'terser',
    sourcemap: false,
  }
})
```

**O que faz:**
- `outDir`: Define pasta de saída como 'dist'
- `minify`: Compacta o código para produção
- `sourcemap: false`: Remove source maps (reduz tamanho)

## 🐛 Troubleshooting

### Erro: "Cannot find module"
**Solução:**
```bash
cd frontend
rm -rf node_modules package-lock.json
npm install
```

### Erro: "Build failed"
**Solução:**
1. Verifique os Build Logs no Vercel
2. Procure por erros de sintaxe em `src/App.jsx`
3. Verifique se todas as dependências estão em `package.json`

### Erro: "404 Not Found" ao acessar rotas
**Solução:**
- Verifique se `vercel.json` tem a seção `rewrites`
- Confirme que está na raiz do projeto (não em frontend/)

### Erro: "Deployment completed but shows blank page"
**Solução:**
1. Abra DevTools (F12)
2. Verifique console para erros
3. Verifique se `index.html` está em `frontend/`
4. Verifique se `main.jsx` está importando corretamente

## 📊 Monitorar Performance

No painel do Vercel:
1. Vá para "Analytics"
2. Verifique Core Web Vitals
3. Monitore tempo de resposta

## 🔄 Redeploy Automático

Vercel faz redeploy automático quando você faz push para main:

```bash
# Fazer alterações
git add .
git commit -m "Descrição das mudanças"
git push origin main

# Vercel detectará e fará redeploy automaticamente
```

## 🎉 Sucesso!

Se você seguiu todos os passos, seu CRM Cielo está online e funcionando! 

**URL do seu site:** `https://seu-projeto.vercel.app`

## 📞 Suporte Adicional

Se ainda tiver problemas:

1. Verifique os Build Logs no Vercel
2. Confirme que todos os arquivos estão no repositório
3. Tente fazer redeploy manualmente no painel do Vercel
4. Limpe cache do navegador (Ctrl+Shift+Delete)

---

**Desenvolvido com ❤️ - Agora seu CRM está no ar!** 🚀
