import React, { useState, useEffect } from 'react';
import { Users, TrendingUp, Filter, Plus, Search, Edit2, Trash2, X, Download, MapPin, Thermometer, Target, Calendar, DollarSign, BarChart3, PieChart, TrendingDown, Menu, Eye } from 'lucide-react';

const CRMCielo = () => {
  const [clientes, setClientes] = useState([]);
  const [abaAtiva, setAbaAtiva] = useState('dashboard');
  const [dashboardAtivo, setDashboardAtivo] = useState('geral');
  const [modalAberto, setModalAberto] = useState(false);
  const [modalTaxasAberto, setModalTaxasAberto] = useState(false);
  const [modalDetalhesAberto, setModalDetalhesAberto] = useState(false);
  const [clienteDetalhes, setClienteDetalhes] = useState(null);
  const [clienteEditando, setClienteEditando] = useState(null);
  const [clienteTaxas, setClienteTaxas] = useState(null);
  const [busca, setBusca] = useState('');
  const [filtroStatus, setFiltroStatus] = useState('todos');
  const [filtroClassificacao, setFiltroClassificacao] = useState('todos');
  const [filtroMes, setFiltroMes] = useState('');
  const [menuMobileAberto, setMenuMobileAberto] = useState(false);

  const concorrentes = [
    'Stone', 'Rede', 'GetNet', 'PagSeguro', 'Mercado Pago',
    'SafraPay', 'Banco do Brasil', 'Bradesco', 'ItaÃº',
    'Santander', 'PicPay', 'InfinitePay', 'Sumup', 'Moderninha'
  ];

  const [formCliente, setFormCliente] = useState({
    documento: '',
    tipoDocumento: 'cpf',
    razaoSocial: '',
    responsavel: '',
    dataNascimento: '',
    contato: '',
    email: '',
    tpv: '',
    cep: '',
    endereco: '',
    observacoes: '',
    classificacao: 'morno',
    status: 'base',
    concorrente: '',
    taxas: { debito: '', credito: '', parcelado: '' },
    dataCadastro: new Date().toISOString(),
    dataCredenciamento: ''
  });

  const [taxasTemp, setTaxasTemp] = useState({ debito: '', credito: '', parcelado: '' });

  useEffect(() => {
    const clientesSalvos = localStorage.getItem('crm_cielo_clientes');
    if (clientesSalvos) setClientes(JSON.parse(clientesSalvos));
  }, []);

  useEffect(() => {
    localStorage.setItem('crm_cielo_clientes', JSON.stringify(clientes));
  }, [clientes]);

  const buscarEnderecoPorCep = async (cep) => {
    const cepLimpo = cep.replace(/\D/g, '');
    if (cepLimpo.length === 8) {
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cepLimpo}/json/`);
        const data = await response.json();
        if (!data.erro) {
          setFormCliente(prev => ({
            ...prev,
            endereco: `${data.logradouro}, ${data.bairro}, ${data.localidade} - ${data.uf}`
          }));
        }
      } catch (error) {
        console.error('Erro ao buscar CEP:', error);
      }
    }
  };

  const formatarDocumento = (valor) => {
    const numeros = valor.replace(/\D/g, '');
    if (numeros.length <= 11) {
      return numeros.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    }
    return numeros.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  };

  const salvarCliente = () => {
    if (!formCliente.documento || !formCliente.responsavel || !formCliente.contato) {
      alert('Preencha os campos obrigatÃ³rios: Documento, ResponsÃ¡vel e Contato');
      return;
    }

    const clienteParaSalvar = {
      ...formCliente,
      id: clienteEditando ? clienteEditando.id : Date.now()
    };

    if (clienteEditando) {
      setClientes(clientes.map(c => c.id === clienteEditando.id ? clienteParaSalvar : c));
    } else {
      setClientes([...clientes, clienteParaSalvar]);
    }
    
    fecharModal();
  };

  const abrirModalTaxas = (cliente) => {
    setClienteTaxas(cliente);
    setTaxasTemp(cliente.taxas || { debito: '', credito: '', parcelado: '' });
    setModalTaxasAberto(true);
  };

  const abrirDetalhes = (cliente) => {
    setClienteDetalhes(cliente);
    setModalDetalhesAberto(true);
  };

  const salvarTaxas = () => {
    setClientes(clientes.map(c => 
      c.id === clienteTaxas.id ? { ...c, taxas: taxasTemp } : c
    ));
    setModalTaxasAberto(false);
    setClienteTaxas(null);
  };

  const excluirCliente = (id) => {
    if (confirm('Tem certeza que deseja excluir este cliente?')) {
      setClientes(clientes.filter(c => c.id !== id));
      setModalDetalhesAberto(false);
    }
  };

  const editarCliente = (cliente) => {
    setClienteEditando(cliente);
    setFormCliente(cliente);
    setModalAberto(true);
    setModalDetalhesAberto(false);
  };

  const fecharModal = () => {
    setModalAberto(false);
    setClienteEditando(null);
    setFormCliente({
      documento: '',
      tipoDocumento: 'cpf',
      razaoSocial: '',
      responsavel: '',
      dataNascimento: '',
      contato: '',
      email: '',
      tpv: '',
      cep: '',
      endereco: '',
      observacoes: '',
      classificacao: 'morno',
      status: 'base',
      concorrente: '',
      taxas: { debito: '', credito: '', parcelado: '' },
      dataCadastro: new Date().toISOString(),
      dataCredenciamento: ''
    });
  };

  const exportarParaExcel = () => {
    const dados = clientes.map(c => ({
      'Documento': c.documento,
      'RazÃ£o Social': c.razaoSocial || '-',
      'ResponsÃ¡vel': c.responsavel,
      'Contato': c.contato,
      'Email': c.email,
      'TPV': c.tpv,
      'EndereÃ§o': c.endereco,
      'ClassificaÃ§Ã£o': c.classificacao,
      'Status': c.status,
      'Concorrente': c.concorrente,
      'Taxa DÃ©bito': c.taxas?.debito ? `${c.taxas.debito}%` : '-',
      'Taxa CrÃ©dito': c.taxas?.credito ? `${c.taxas.credito}%` : '-',
      'Taxa Parcelado': c.taxas?.parcelado ? `${c.taxas.parcelado}%` : '-',
      'Data Cadastro': new Date(c.dataCadastro).toLocaleDateString(),
      'Data Credenciamento': c.dataCredenciamento ? new Date(c.dataCredenciamento).toLocaleDateString() : '-',
      'ObservaÃ§Ãµes': c.observacoes
    }));

    const csv = [
      Object.keys(dados[0]).join(','),
      ...dados.map(row => Object.values(row).map(val => `"${val}"`).join(','))
    ].join('\n');

    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `carteira_cielo_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const calcularEstatisticas = () => {
    const total = clientes.length;
    const porStatus = {
      base: clientes.filter(c => c.status === 'base').length,
      visita: clientes.filter(c => c.status === 'visita').length,
      negociando: clientes.filter(c => c.status === 'negociando').length,
      credenciado: clientes.filter(c => c.status === 'credenciado').length
    };
    const porClassificacao = {
      frio: clientes.filter(c => c.classificacao === 'frio').length,
      morno: clientes.filter(c => c.classificacao === 'morno').length,
      quente: clientes.filter(c => c.classificacao === 'quente').length
    };
    const tpvTotal = clientes.reduce((acc, c) => acc + (parseFloat(c.tpv) || 0), 0);
    const tpvMedio = total > 0 ? tpvTotal / total : 0;
    
    const concorrentesCount = {};
    clientes.forEach(c => {
      if (c.concorrente) {
        concorrentesCount[c.concorrente] = (concorrentesCount[c.concorrente] || 0) + 1;
      }
    });

    return { total, porStatus, porClassificacao, tpvTotal, tpvMedio, concorrentesCount };
  };

  const stats = calcularEstatisticas();

  const clientesFiltrados = clientes.filter(c => {
    const matchBusca = c.responsavel.toLowerCase().includes(busca.toLowerCase()) ||
                       c.documento.includes(busca) ||
                       c.email.toLowerCase().includes(busca.toLowerCase()) ||
                       (c.razaoSocial && c.razaoSocial.toLowerCase().includes(busca.toLowerCase()));
    const matchStatus = filtroStatus === 'todos' || c.status === filtroStatus;
    const matchClassificacao = filtroClassificacao === 'todos' || c.classificacao === filtroClassificacao;
    
    let matchMes = true;
    if (filtroMes) {
      const dataFiltro = new Date(filtroMes);
      const dataCliente = c.status === 'credenciado' && c.dataCredenciamento 
        ? new Date(c.dataCredenciamento)
        : new Date(c.dataCadastro);
      matchMes = dataCliente.getMonth() === dataFiltro.getMonth() && 
                 dataCliente.getFullYear() === dataFiltro.getFullYear();
    }
    
    return matchBusca && matchStatus && matchClassificacao && matchMes;
  });

  const obterIconeClassificacao = (classificacao) => {
    switch(classificacao) {
      case 'frio': return 'ðŸ¥¶';
      case 'morno': return 'ðŸ˜';
      case 'quente': return 'ðŸ”¥';
      default: return 'ðŸ˜';
    }
  };

  const obterCorClassificacao = (classificacao) => {
    switch(classificacao) {
      case 'frio': return 'bg-blue-100 text-blue-800';
      case 'morno': return 'bg-yellow-100 text-yellow-800';
      case 'quente': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const obterCorStatus = (status) => {
    switch(status) {
      case 'base': return 'bg-gray-100 text-gray-800';
      case 'visita': return 'bg-blue-100 text-blue-800';
      case 'negociando': return 'bg-orange-100 text-orange-800';
      case 'credenciado': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 overflow-x-hidden">
      <div className="w-full max-w-7xl mx-auto p-3 sm:p-6 pb-24 sm:pb-6">
        {/* Header */}
        <header className="bg-white rounded-lg shadow-xl p-4 sm:p-6 mb-4 sm:mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 sm:w-10 sm:h-10 text-white" />
              </div>
              <div>
                <h1 className="text-xl sm:text-3xl font-bold text-gray-900">CRM Cielo</h1>
                <p className="text-xs sm:text-base text-gray-600 hidden sm:block">GestÃ£o de Carteira e Pipeline</p>
              </div>
            </div>
            <button
              onClick={exportarParaExcel}
              className="bg-green-600 text-white px-3 py-2 sm:px-4 sm:py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2 text-sm sm:text-base"
            >
              <Download className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="hidden sm:inline">Exportar</span>
            </button>
          </div>
        </header>

        {/* Navigation Desktop */}
        <nav className="hidden sm:flex bg-white rounded-lg shadow-xl p-2 mb-6 gap-2">
          <button
            onClick={() => setAbaAtiva('dashboard')}
            className={`flex-1 py-3 px-4 rounded-lg font-semibold transition-all ${
              abaAtiva === 'dashboard' ? 'bg-blue-600 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <BarChart3 className="w-5 h-5 inline mr-2" />
            Dashboards
          </button>
          <button
            onClick={() => setAbaAtiva('carteira')}
            className={`flex-1 py-3 px-4 rounded-lg font-semibold transition-all ${
              abaAtiva === 'carteira' ? 'bg-blue-600 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Users className="w-5 h-5 inline mr-2" />
            Carteira
          </button>
        </nav>

        {/* Navigation Mobile */}
        <nav className="sm:hidden bg-white rounded-lg shadow-xl p-2 mb-4 grid grid-cols-2 gap-2">
          <button
            onClick={() => setAbaAtiva('dashboard')}
            className={`py-3 px-3 rounded-lg font-semibold transition-all text-sm ${
              abaAtiva === 'dashboard' ? 'bg-blue-600 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <BarChart3 className="w-4 h-4 inline mr-1" />
            Dashboard
          </button>
          <button
            onClick={() => setAbaAtiva('carteira')}
            className={`py-3 px-3 rounded-lg font-semibold transition-all text-sm ${
              abaAtiva === 'carteira' ? 'bg-blue-600 text-white' : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Users className="w-4 h-4 inline mr-1" />
            Carteira
          </button>
        </nav>

        {abaAtiva === 'dashboard' && (
          <div>
            {/* Dashboard Tabs */}
            <div className="bg-white rounded-lg shadow-xl p-2 sm:p-4 mb-4 sm:mb-6">
              <div className="grid grid-cols-2 sm:flex gap-2 overflow-x-auto">
                <button
                  onClick={() => setDashboardAtivo('geral')}
                  className={`px-3 py-2 sm:px-4 sm:py-2 rounded-lg font-semibold whitespace-nowrap text-xs sm:text-base ${
                    dashboardAtivo === 'geral' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  Geral
                </button>
                <button
                  onClick={() => setDashboardAtivo('funil')}
                  className={`px-3 py-2 sm:px-4 sm:py-2 rounded-lg font-semibold whitespace-nowrap text-xs sm:text-base ${
                    dashboardAtivo === 'funil' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  Funil
                </button>
                <button
                  onClick={() => setDashboardAtivo('concorrencia')}
                  className={`px-3 py-2 sm:px-4 sm:py-2 rounded-lg font-semibold whitespace-nowrap text-xs sm:text-base ${
                    dashboardAtivo === 'concorrencia' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  ConcorrÃªncia
                </button>
                <button
                  onClick={() => setDashboardAtivo('financeiro')}
                  className={`px-3 py-2 sm:px-4 sm:py-2 rounded-lg font-semibold whitespace-nowrap text-xs sm:text-base ${
                    dashboardAtivo === 'financeiro' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  Financeiro
                </button>
              </div>
            </div>

            {dashboardAtivo === 'geral' && (
              <div>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6 mb-4 sm:mb-6">
                  <div className="bg-white rounded-lg shadow-xl p-4 sm:p-6">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center sm:justify-between">
                      <div className="mb-2 sm:mb-0">
                        <p className="text-gray-600 text-xs sm:text-sm">Total</p>
                        <p className="text-2xl sm:text-3xl font-bold text-gray-900">{stats.total}</p>
                      </div>
                      <Users className="w-8 h-8 sm:w-12 sm:h-12 text-blue-600 opacity-50" />
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-xl p-4 sm:p-6">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center sm:justify-between">
                      <div className="mb-2 sm:mb-0">
                        <p className="text-gray-600 text-xs sm:text-sm">Credenciados</p>
                        <p className="text-2xl sm:text-3xl font-bold text-green-600">{stats.porStatus.credenciado}</p>
                      </div>
                      <Target className="w-8 h-8 sm:w-12 sm:h-12 text-green-600 opacity-50" />
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-xl p-4 sm:p-6">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center sm:justify-between">
                      <div className="mb-2 sm:mb-0">
                        <p className="text-gray-600 text-xs sm:text-sm">Negociando</p>
                        <p className="text-2xl sm:text-3xl font-bold text-orange-600">{stats.porStatus.negociando}</p>
                      </div>
                      <TrendingUp className="w-8 h-8 sm:w-12 sm:h-12 text-orange-600 opacity-50" />
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-xl p-4 sm:p-6">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center sm:justify-between">
                      <div className="mb-2 sm:mb-0">
                        <p className="text-gray-600 text-xs sm:text-sm">TPV MÃ©dio</p>
                        <p className="text-lg sm:text-2xl font-bold text-purple-600">
                          R$ {stats.tpvMedio.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                        </p>
                      </div>
                      <DollarSign className="w-8 h-8 sm:w-12 sm:h-12 text-purple-600 opacity-50" />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                  <div className="bg-white rounded-lg shadow-xl p-4 sm:p-6">
                    <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                      <Thermometer className="w-5 h-5 sm:w-6 sm:h-6" />
                      ClassificaÃ§Ã£o
                    </h3>
                    <div className="space-y-2 sm:space-y-3">
                      <div className="flex justify-between items-center p-3 sm:p-4 bg-red-50 rounded-lg">
                        <span className="font-semibold text-red-900 flex items-center gap-2 text-sm sm:text-base">
                          ðŸ”¥ Quentes
                        </span>
                        <span className="text-xl sm:text-2xl font-bold text-red-600">{stats.porClassificacao.quente}</span>
                      </div>
                      <div className="flex justify-between items-center p-3 sm:p-4 bg-yellow-50 rounded-lg">
                        <span className="font-semibold text-yellow-900 flex items-center gap-2 text-sm sm:text-base">
                          ðŸ˜ Mornos
                        </span>
                        <span className="text-xl sm:text-2xl font-bold text-yellow-600">{stats.porClassificacao.morno}</span>
                      </div>
                      <div className="flex justify-between items-center p-3 sm:p-4 bg-blue-50 rounded-lg">
                        <span className="font-semibold text-blue-900 flex items-center gap-2 text-sm sm:text-base">
                          ðŸ¥¶ Frios
                        </span>
                        <span className="text-xl sm:text-2xl font-bold text-blue-600">{stats.porClassificacao.frio}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-xl p-4 sm:p-6">
                    <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                      <Target className="w-5 h-5 sm:w-6 sm:h-6" />
                      Pipeline
                    </h3>
                    <div className="space-y-2 sm:space-y-3">
                      <div className="flex justify-between items-center p-3 sm:p-4 bg-gray-50 rounded-lg">
                        <span className="font-semibold text-gray-900 text-sm sm:text-base">Base</span>
                        <span className="text-xl sm:text-2xl font-bold text-gray-600">{stats.porStatus.base}</span>
                      </div>
                      <div className="flex justify-between items-center p-3 sm:p-4 bg-blue-50 rounded-lg">
                        <span className="font-semibold text-blue-900 text-sm sm:text-base">Visita</span>
                        <span className="text-xl sm:text-2xl font-bold text-blue-600">{stats.porStatus.visita}</span>
                      </div>
                      <div className="flex justify-between items-center p-3 sm:p-4 bg-orange-50 rounded-lg">
                        <span className="font-semibold text-orange-900 text-sm sm:text-base">Negociando</span>
                        <span className="text-xl sm:text-2xl font-bold text-orange-600">{stats.porStatus.negociando}</span>
                      </div>
                      <div className="flex justify-between items-center p-3 sm:p-4 bg-green-50 rounded-lg">
                        <span className="font-semibold text-green-900 text-sm sm:text-base">Credenciado</span>
                        <span className="text-xl sm:text-2xl font-bold text-green-600">{stats.porStatus.credenciado}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {dashboardAtivo === 'funil' && (
              <div className="bg-white rounded-lg shadow-xl p-4 sm:p-6">
                <h3 className="text-xl sm:text-2xl font-bold text-gray-800 mb-4 sm:mb-6">Funil de ConversÃ£o</h3>
                <div className="space-y-3 sm:space-y-4">
                  {[
                    { nome: 'Base', quantidade: stats.porStatus.base, cor: 'bg-gray-400', largura: '100%' },
                    { nome: 'Visita', quantidade: stats.porStatus.visita, cor: 'bg-blue-500', largura: '80%' },
                    { nome: 'Negociando', quantidade: stats.porStatus.negociando, cor: 'bg-orange-500', largura: '60%' },
                    { nome: 'Credenciado', quantidade: stats.porStatus.credenciado, cor: 'bg-green-500', largura: '40%' }
                  ].map((etapa, i) => (
                    <div key={i} className="relative">
                      <div className="flex justify-between mb-2">
                        <span className="font-semibold text-gray-700 text-sm sm:text-base">{etapa.nome}</span>
                        <span className="font-bold text-gray-900 text-sm sm:text-base">{etapa.quantidade}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-10 sm:h-12" style={{ width: etapa.largura }}>
                        <div 
                          className={`${etapa.cor} h-10 sm:h-12 rounded-full flex items-center justify-center text-white font-bold transition-all duration-500 text-sm sm:text-base`}
                          style={{ width: stats.total > 0 ? `${(etapa.quantidade / stats.total) * 100}%` : '0%' }}
                        >
                          {stats.total > 0 ? `${Math.round((etapa.quantidade / stats.total) * 100)}%` : '0%'}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-6 sm:mt-8 p-3 sm:p-4 bg-blue-50 rounded-lg">
                  <p className="text-xs sm:text-sm text-gray-700">
                    <strong>Taxa de ConversÃ£o:</strong> {stats.total > 0 ? `${((stats.porStatus.credenciado / stats.total) * 100).toFixed(1)}%` : '0%'} dos leads se tornaram clientes
                  </p>
                </div>
              </div>
            )}

            {dashboardAtivo === 'concorrencia' && (
              <div className="bg-white rounded-lg shadow-xl p-4 sm:p-6">
                <h3 className="text-xl sm:text-2xl font-bold text-gray-800 mb-4 sm:mb-6">AnÃ¡lise de ConcorrÃªncia</h3>
                <div className="space-y-2 sm:space-y-3">
                  {Object.entries(stats.concorrentesCount)
                    .sort((a, b) => b[1] - a[1])
                    .map(([concorrente, quantidade]) => (
                      <div key={concorrente} className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
                        <div className="w-full sm:w-32 font-semibold text-gray-700 text-sm sm:text-base">{concorrente}</div>
                        <div className="flex-1">
                          <div className="w-full bg-gray-200 rounded-full h-8">
                            <div 
                              className="bg-gradient-to-r from-red-500 to-red-600 h-8 rounded-full flex items-center justify-end pr-3 text-white font-bold text-xs sm:text-sm"
                              style={{ width: `${(quantidade / stats.total) * 100}%` }}
                            >
                              {quantidade} ({((quantidade / stats.total) * 100).toFixed(1)}%)
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  {Object.keys(stats.concorrentesCount).length === 0 && (
                    <p className="text-gray-500 text-center py-8 text-sm sm:text-base">Nenhum concorrente cadastrado</p>
                  )}
                </div>
              </div>
            )}

            {dashboardAtivo === 'financeiro' && (
              <div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                  <div className="bg-white rounded-lg shadow-xl p-4 sm:p-6">
                    <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4">Potencial de TPV</h3>
                    <div className="space-y-3 sm:space-y-4">
                      <div className="p-3 sm:p-4 bg-purple-50 rounded-lg">
                        <p className="text-xs sm:text-sm text-gray-600">TPV Total</p>
                        <p className="text-2xl sm:text-3xl font-bold text-purple-600">
                          R$ {stats.tpvTotal.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                        </p>
                      </div>
                      <div className="p-3 sm:p-4 bg-green-50 rounded-lg">
                        <p className="text-xs sm:text-sm text-gray-600">TPV MÃ©dio</p>
                        <p className="text-2xl sm:text-3xl font-bold text-green-600">
                          R$ {stats.tpvMedio.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                        </p>
                      </div>
                      <div className="p-3 sm:p-4 bg-blue-50 rounded-lg">
                        <p className="text-xs sm:text-sm text-gray-600">Em NegociaÃ§Ã£o</p>
                        <p className="text-2xl sm:text-3xl font-bold text-blue-600">
                          R$ {clientes
                            .filter(c => c.status === 'negociando')
                            .reduce((acc, c) => acc + (parseFloat(c.tpv) || 0), 0)
                            .toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-lg shadow-xl p-4 sm:p-6">
                    <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4">Faixas de TPV</h3>
                    <div className="space-y-2 sm:space-y-3">
                      {[
                        { label: 'AtÃ© R$ 10k', count: clientes.filter(c => parseFloat(c.tpv) <= 10000).length },
                        { label: 'R$ 10k - R$ 50k', count: clientes.filter(c => parseFloat(c.tpv) > 10000 && parseFloat(c.tpv) <= 50000).length },
                        { label: 'R$ 50k - R$ 100k', count: clientes.filter(c => parseFloat(c.tpv) > 50000 && parseFloat(c.tpv) <= 100000).length },
                        { label: 'Acima de R$ 100k', count: clientes.filter(c => parseFloat(c.tpv) > 100000).length }
                      ].map((faixa, i) => (
                        <div key={i} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                          <span className="font-semibold text-gray-700 text-xs sm:text-sm">{faixa.label}</span>
                          <span className="text-lg sm:text-xl font-bold text-gray-900">{faixa.count}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {abaAtiva === 'carteira' && (
          <div className="bg-white rounded-lg shadow-xl p-4 sm:p-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4 sm:mb-6">
              <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Carteira</h2>
              <button
                onClick={() => setModalAberto(true)}
                className="w-full sm:w-auto bg-blue-600 text-white px-4 py-3 sm:py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 font-semibold"
              >
                <Plus className="w-5 h-5" />
                Novo Cliente
              </button>
            </div>

            {/* Filtros */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-4 sm:mb-6">
              <div className="relative">
                <Search className="w-4 h-4 sm:w-5 sm:h-5 absolute left-3 top-3 text-gray-400" />
                <input
                  type="text"
                  placeholder="Buscar..."
                  value={busca}
                  onChange={(e) => setBusca(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                />
              </div>

              <select
                value={filtroStatus}
                onChange={(e) => setFiltroStatus(e.target.value)}
                className="px-4 py-2 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              >
                <option value="todos">Todos Status</option>
                <option value="base">Base</option>
                <option value="visita">Visita</option>
                <option value="negociando">Negociando</option>
                <option value="credenciado">Credenciado</option>
              </select>

              <select
                value={filtroClassificacao}
                onChange={(e) => setFiltroClassificacao(e.target.value)}
                className="px-4 py-2 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              >
                <option value="todos">Todas</option>
                <option value="frio">ðŸ¥¶ Frio</option>
                <option value="morno">ðŸ˜ Morno</option>
                <option value="quente">ðŸ”¥ Quente</option>
              </select>

              <input
                type="month"
                value={filtroMes}
                onChange={(e) => setFiltroMes(e.target.value)}
                className="px-4 py-2 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
              />
            </div>

            {/* Lista Mobile - Cards */}
            <div className="block lg:hidden space-y-3">
              {clientesFiltrados.map(cliente => (
                <div key={cliente.id} className="bg-gray-50 rounded-lg p-4 shadow">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-900">{cliente.razaoSocial || cliente.responsavel}</h3>
                      <p className="text-sm text-gray-600">{cliente.documento}</p>
                    </div>
                    <button
                      onClick={() => abrirDetalhes(cliente)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">TPV:</span>
                      <span className="font-semibold text-green-600">
                        R$ {parseFloat(cliente.tpv || 0).toLocaleString('pt-BR', { minimumFractionDigits: 0 })}
                      </span>
                    </div>
                    
                    <div className="flex gap-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${obterCorClassificacao(cliente.classificacao)}`}>
                        {obterIconeClassificacao(cliente.classificacao)} {cliente.classificacao}
                      </span>
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${obterCorStatus(cliente.status)}`}>
                        {cliente.status}
                      </span>
                    </div>
                    
                    {cliente.concorrente && (
                      <p className="text-xs text-gray-600">
                        Concorrente: <span className="font-semibold">{cliente.concorrente}</span>
                      </p>
                    )}
                  </div>
                </div>
              ))}
              {clientesFiltrados.length === 0 && (
                <p className="text-gray-500 text-center py-8">Nenhum cliente encontrado</p>
              )}
            </div>

            {/* Tabela Desktop */}
            <div className="hidden lg:block overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Cliente</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Contato</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">TPV</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">ClassificaÃ§Ã£o</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Status</th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-gray-700">Concorrente</th>
                    <th className="px-4 py-3 text-center text-sm font-semibold text-gray-700">AÃ§Ãµes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {clientesFiltrados.map(cliente => (
                    <tr key={cliente.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3">
                        <div>
                          <p className="font-semibold">{cliente.razaoSocial || cliente.responsavel}</p>
                          <p className="text-sm text-gray-500">{cliente.documento}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div>
                          <p className="text-sm">{cliente.contato}</p>
                          <p className="text-xs text-gray-500">{cliente.email}</p>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-semibold text-green-600">
                          R$ {parseFloat(cliente.tpv || 0).toLocaleString('pt-BR', { minimumFractionDigits: 0 })}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${obterCorClassificacao(cliente.classificacao)}`}>
                          {obterIconeClassificacao(cliente.classificacao)} {cliente.classificacao.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${obterCorStatus(cliente.status)}`}>
                          {cliente.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div>
                          <p className="text-sm font-medium">{cliente.concorrente || '-'}</p>
                          {cliente.concorrente && (
                            <button
                              onClick={() => abrirModalTaxas(cliente)}
                              className="text-xs text-blue-600 hover:underline"
                            >
                              Ver taxas
                            </button>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2 justify-center">
                          <button
                            onClick={() => editarCliente(cliente)}
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <Edit2 className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => excluirCliente(cliente.id)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {clientesFiltrados.length === 0 && (
                <p className="text-gray-500 text-center py-8">Nenhum cliente encontrado</p>
              )}
            </div>
          </div>
        )}

        {/* Modal Detalhes (Mobile) */}
        {modalDetalhesAberto && clienteDetalhes && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end sm:items-center justify-center z-50">
            <div className="bg-white rounded-t-2xl sm:rounded-lg shadow-xl w-full sm:max-w-2xl sm:mx-4 max-h-[90vh] overflow-y-auto">
              <div className="sticky top-0 bg-white border-b p-4 flex justify-between items-center">
                <h3 className="text-xl font-bold text-gray-800">Detalhes do Cliente</h3>
                <button onClick={() => setModalDetalhesAberto(false)} className="text-gray-500 hover:text-gray-700">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-4 space-y-4">
                <div>
                  <h4 className="font-bold text-lg text-gray-900 mb-1">
                    {clienteDetalhes.razaoSocial || clienteDetalhes.responsavel}
                  </h4>
                  <p className="text-sm text-gray-600">{clienteDetalhes.documento}</p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-xs text-gray-600 mb-1">ResponsÃ¡vel</p>
                    <p className="font-semibold text-sm">{clienteDetalhes.responsavel}</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-xs text-gray-600 mb-1">TPV</p>
                    <p className="font-semibold text-green-600 text-sm">
                      R$ {parseFloat(clienteDetalhes.tpv || 0).toLocaleString('pt-BR')}
                    </p>
                  </div>
                </div>

                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-xs text-gray-600 mb-1">Contato</p>
                  <p className="font-semibold text-sm">{clienteDetalhes.contato}</p>
                  {clienteDetalhes.email && (
                    <p className="text-sm text-gray-600 mt-1">{clienteDetalhes.email}</p>
                  )}
                </div>

                {clienteDetalhes.endereco && (
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-xs text-gray-600 mb-1">EndereÃ§o</p>
                    <p className="text-sm">{clienteDetalhes.endereco}</p>
                  </div>
                )}

                <div className="flex gap-2">
                  <span className={`px-3 py-2 rounded-lg text-sm font-semibold flex-1 text-center ${obterCorClassificacao(clienteDetalhes.classificacao)}`}>
                    {obterIconeClassificacao(clienteDetalhes.classificacao)} {clienteDetalhes.classificacao.toUpperCase()}
                  </span>
                  <span className={`px-3 py-2 rounded-lg text-sm font-semibold flex-1 text-center ${obterCorStatus(clienteDetalhes.status)}`}>
                    {clienteDetalhes.status.toUpperCase()}
                  </span>
                </div>

                {clienteDetalhes.concorrente && (
                  <div className="bg-red-50 p-3 rounded-lg">
                    <p className="text-xs text-gray-600 mb-2">Concorrente Atual</p>
                    <p className="font-semibold text-red-900 mb-2">{clienteDetalhes.concorrente}</p>
                    {(clienteDetalhes.taxas?.debito || clienteDetalhes.taxas?.credito || clienteDetalhes.taxas?.parcelado) && (
                      <div className="space-y-1 text-sm">
                        {clienteDetalhes.taxas.debito && <p>DÃ©bito: <strong>{clienteDetalhes.taxas.debito}%</strong></p>}
                        {clienteDetalhes.taxas.credito && <p>CrÃ©dito: <strong>{clienteDetalhes.taxas.credito}%</strong></p>}
                        {clienteDetalhes.taxas.parcelado && <p>Parcelado: <strong>{clienteDetalhes.taxas.parcelado}%</strong></p>}
                      </div>
                    )}
                  </div>
                )}

                {clienteDetalhes.observacoes && (
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-xs text-gray-600 mb-1">ObservaÃ§Ãµes</p>
                    <p className="text-sm">{clienteDetalhes.observacoes}</p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3 pt-4 border-t">
                  <button
                    onClick={() => editarCliente(clienteDetalhes)}
                    className="bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold flex items-center justify-center gap-2"
                  >
                    <Edit2 className="w-4 h-4" />
                    Editar
                  </button>
                  <button
                    onClick={() => excluirCliente(clienteDetalhes.id)}
                    className="bg-red-600 text-white px-4 py-3 rounded-lg hover:bg-red-700 transition-colors font-semibold flex items-center justify-center gap-2"
                  >
                    <Trash2 className="w-4 h-4" />
                    Excluir
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal Cadastro/EdiÃ§Ã£o */}
        {modalAberto && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end sm:items-center justify-center p-0 sm:p-4 z-50 overflow-y-auto">
            <div className="bg-white rounded-t-2xl sm:rounded-lg shadow-xl w-full sm:max-w-3xl max-h-[95vh] sm:max-h-[90vh] overflow-y-auto">
              <div className="sticky top-0 bg-white border-b p-4 sm:p-6 flex justify-between items-center z-10">
                <h3 className="text-xl sm:text-2xl font-bold text-gray-800">
                  {clienteEditando ? 'Editar Cliente' : 'Novo Cliente'}
                </h3>
                <button onClick={fecharModal} className="text-gray-500 hover:text-gray-700">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-4 sm:p-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Tipo *</label>
                    <select
                      value={formCliente.tipoDocumento}
                      onChange={(e) => setFormCliente({ ...formCliente, tipoDocumento: e.target.value })}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    >
                      <option value="cpf">CPF</option>
                      <option value="cnpj">CNPJ</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">
                      {formCliente.tipoDocumento === 'cpf' ? 'CPF' : 'CNPJ'} *
                    </label>
                    <input
                      type="text"
                      placeholder={formCliente.tipoDocumento === 'cpf' ? '000.000.000-00' : '00.000.000/0000-00'}
                      value={formCliente.documento}
                      onChange={(e) => setFormCliente({ ...formCliente, documento: formatarDocumento(e.target.value) })}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    />
                  </div>
                </div>

                {formCliente.tipoDocumento === 'cnpj' && (
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">RazÃ£o Social</label>
                    <input
                      type="text"
                      placeholder="Nome da empresa"
                      value={formCliente.razaoSocial}
                      onChange={(e) => setFormCliente({ ...formCliente, razaoSocial: e.target.value })}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    />
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">ResponsÃ¡vel *</label>
                    <input
                      type="text"
                      placeholder="Nome"
                      value={formCliente.responsavel}
                      onChange={(e) => setFormCliente({ ...formCliente, responsavel: e.target.value })}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    />
                  </div>

                  {formCliente.tipoDocumento === 'cpf' && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">Data Nascimento</label>
                      <input
                        type="date"
                        value={formCliente.dataNascimento}
                        onChange={(e) => setFormCliente({ ...formCliente, dataNascimento: e.target.value })}
                        className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                      />
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Contato *</label>
                    <input
                      type="tel"
                      placeholder="(21) 99999-9999"
                      value={formCliente.contato}
                      onChange={(e) => setFormCliente({ ...formCliente, contato: e.target.value })}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">E-mail</label>
                    <input
                      type="email"
                      placeholder="email@exemplo.com"
                      value={formCliente.email}
                      onChange={(e) => setFormCliente({ ...formCliente, email: e.target.value })}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">TPV Mensal</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="R$ 0,00"
                    value={formCliente.tpv}
                    onChange={(e) => setFormCliente({ ...formCliente, tpv: e.target.value })}
                    className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">CEP</label>
                    <input
                      type="text"
                      placeholder="00000-000"
                      value={formCliente.cep}
                      onChange={(e) => {
                        const cep = e.target.value;
                        setFormCliente({ ...formCliente, cep });
                        if (cep.replace(/\D/g, '').length === 8) {
                          buscarEnderecoPorCep(cep);
                        }
                      }}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">EndereÃ§o</label>
                    <input
                      type="text"
                      placeholder="Rua, nÃºmero, bairro"
                      value={formCliente.endereco}
                      onChange={(e) => setFormCliente({ ...formCliente, endereco: e.target.value })}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">ClassificaÃ§Ã£o</label>
                    <select
                      value={formCliente.classificacao}
                      onChange={(e) => setFormCliente({ ...formCliente, classificacao: e.target.value })}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    >
                      <option value="frio">ðŸ¥¶ Frio</option>
                      <option value="morno">ðŸ˜ Morno</option>
                      <option value="quente">ðŸ”¥ Quente</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Status</label>
                    <select
                      value={formCliente.status}
                      onChange={(e) => {
                        const novoStatus = e.target.value;
                        setFormCliente({ 
                          ...formCliente, 
                          status: novoStatus,
                          dataCredenciamento: novoStatus === 'credenciado' && !formCliente.dataCredenciamento 
                            ? new Date().toISOString().split('T')[0] 
                            : formCliente.dataCredenciamento
                        });
                      }}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    >
                      <option value="base">Base</option>
                      <option value="visita">Visita</option>
                      <option value="negociando">Negociando</option>
                      <option value="credenciado">Credenciado</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Concorrente</label>
                    <select
                      value={formCliente.concorrente}
                      onChange={(e) => setFormCliente({ ...formCliente, concorrente: e.target.value })}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    >
                      <option value="">Nenhum</option>
                      {concorrentes.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {formCliente.status === 'credenciado' && (
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1">Data Credenciamento</label>
                    <input
                      type="date"
                      value={formCliente.dataCredenciamento}
                      onChange={(e) => setFormCliente({ ...formCliente, dataCredenciamento: e.target.value })}
                      className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">ObservaÃ§Ãµes</label>
                  <textarea
                    placeholder="AnotaÃ§Ãµes..."
                    value={formCliente.observacoes}
                    onChange={(e) => setFormCliente({ ...formCliente, observacoes: e.target.value })}
                    rows="3"
                    className="w-full px-4 py-2 sm:py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="sticky bottom-0 bg-white border-t p-4 sm:p-6 flex gap-3">
                <button
                  onClick={fecharModal}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-semibold"
                >
                  Cancelar
                </button>
                <button
                  onClick={salvarCliente}
                  className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
                >
                  Salvar
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal Taxas */}
        {modalTaxasAberto && clienteTaxas && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end sm:items-center justify-center p-0 sm:p-4 z-50">
            <div className="bg-white rounded-t-2xl sm:rounded-lg shadow-xl w-full sm:max-w-md">
              <div className="p-4 sm:p-6 border-b flex justify-between items-center">
                <h3 className="text-lg sm:text-xl font-bold text-gray-800">
                  Taxas - {clienteTaxas.concorrente}
                </h3>
                <button onClick={() => setModalTaxasAberto(false)} className="text-gray-500 hover:text-gray-700">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-4 sm:p-6 space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Taxa DÃ©bito (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={taxasTemp.debito}
                    onChange={(e) => setTaxasTemp({ ...taxasTemp, debito: e.target.value })}
                    className="w-full px-4 py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                  />
                  {taxasTemp.debito && <p className="text-sm text-gray-500 mt-1">Taxa: {taxasTemp.debito}%</p>}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Taxa CrÃ©dito (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={taxasTemp.credito}
                    onChange={(e) => setTaxasTemp({ ...taxasTemp, credito: e.target.value })}
                    className="w-full px-4 py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                  />
                  {taxasTemp.credito && <p className="text-sm text-gray-500 mt-1">Taxa: {taxasTemp.credito}%</p>}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Taxa Parcelado (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={taxasTemp.parcelado}
                    onChange={(e) => setTaxasTemp({ ...taxasTemp, parcelado: e.target.value })}
                    className="w-full px-4 py-3 text-sm sm:text-base border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                  />
                  {taxasTemp.parcelado && <p className="text-sm text-gray-500 mt-1">Taxa: {taxasTemp.parcelado}%</p>}
                </div>
              </div>

              <div className="p-4 sm:p-6 border-t flex gap-3">
                <button
                  onClick={() => setModalTaxasAberto(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors font-semibold"
                >
                  Cancelar
                </button>
                <button
                  onClick={salvarTaxas}
                  className="flex-1 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
                >
                  Salvar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Floating Action Button (Mobile) */}
      <button
        onClick={() => setModalAberto(true)}
        className="sm:hidden fixed bottom-6 right-6 w-14 h-14 bg-blue-600 text-white rounded-full shadow-2xl hover:bg-blue-700 transition-all flex items-center justify-center z-40"
      >
        <Plus className="w-6 h-6" />
      </button>
    </div>
  );
};

export default CRMCielo;